﻿window.onload = function load() {
    Sys.WebForms.PageRequestManager.getInstance().add_endRequest(EndRequestHandler);
}
$(document).ready(function () {
    $("a#show-panel").click(function () {
        $("#lightbox, #lightbox-panel").fadeIn(400);
    })
    $("a#close-panel").click(function () {
        $("#lightbox, #lightbox-panel").fadeOut(400);
    })
    $("a#close-panel1").click(function () {
        $("#lightbox, #lightbox-panel").fadeOut(400);
    })
    $("a#close-panel2").click(function () {
        $("#lightbox, #lightbox-panel").fadeOut(400);
    })
    $("a#close-panel3").click(function () {
        $("#lightbox, #lightbox-panel").fadeOut(400);
    })
})
function showLoading() {
    alert('Client clicked');
    var firstLight = document.getElementById('clickMe');
    firstLight.onclick.apply(firstLight);
}
function treeViewPostBack() {
    //alert('post back returned');
    document.getElementById('isTreePostBack').value = 'true';
    //    try {
    //        document.getElementById('lightbox-panel').style.border = '10px solid #CCCCCC';
    //        document.getElementById('lightbox-panel').style.width = '310px';
    //        document.getElementById('lightbox-panel').style.padding = '10px 15px';
    //    }
    //    catch (e) {
    //        alert('Exception in treeAViewPB: ' + e);
    //    }
}
function ShowLoadingGif() {
    $("#lightbox, #lightbox-panel1").fadeIn(400);
}
function HideLoadingGif() {
    $("#lightbox, #lightbox-panel1").fadeOut(400);
}
function showLightDialog() {
    $("#lightbox, #lightbox-panel").fadeIn(400);
}
function hideFreeTextBox() {
    $("#lightbox, #lightbox-panel").fadeOut(400);
}
function EndRequestHandler() {
    //alert('end request called');
    try {
        if (document.getElementById('isTreePostBack').value == 'true') {
            //alert('isTreePostBack is true');
            //anchorClick(event, document.getElementById('show-panel'))
            showLightDialog();
            document.getElementById('isTreePostBack').value = 'false';
        }
        else {
            //            document.getElementById('overlay').style.display = 'none';  //style.visibility = 'hidden';
            //            document.getElementById('lightbox').style.display = 'none';
            //            document.getElementById('pdivfront').style.display = 'none';
            //            document.getElementById('pdivback').style.display = 'none';
            HideLoadingGif();
        }
    }
    catch (e) {
        //alert('EndRequest: '+e);
    }
    //document.getElementById('pdivFront').style.display = 'none';
}
function aClick() {
    alert('called click');
}

function fakeClick(event, anchorObj) {
    //alert('i am called');
    try {
        //alert('fake click called');
        document.getElementById('pdivfront').style.display = 'block';
        //alert('pdivfront found');
        document.getElementById('pdivback').style.display = 'block';
        //document.getElementById('pdivback').removeAttribute('style');
        //var div = document.getElementById('pdivback');
        //div.removeAttribute('style');
        //div.setAttribute('style', 'position: absolute; z-index: 100; height: 550px; width: 800px;margin-left: 10px; margin-top: 40px;background-color:gray;');
    }
    catch (e) {
        alert(e);
    }
    //alert('removed');
    if (anchorObj.click) {
        anchorObj.click()
    } else if (document.createEvent) {
        if (event.target !== anchorObj) {
            var evt = document.createEvent("MouseEvents");
            evt.initMouseEvent("click", true, true, window,
          0, 0, 0, 0, 0, false, false, false, false, 0, null);
            var allowDefault = anchorObj.dispatchEvent(evt);
            // you can check allowDefault for false to see if
            // any handler called evt.preventDefault().
            // Firefox will *not* redirect to anchorObj.href
            // for you. However every other browser will.
        }
    }

    //alert('removed');
    //document.getElementById('pdivFront').style.display = 'inline';
}